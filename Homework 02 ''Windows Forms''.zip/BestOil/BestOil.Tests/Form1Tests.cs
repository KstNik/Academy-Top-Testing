﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace BestOil.Tests {
    [TestClass]
    public class Form1Tests {
        [TestMethod]
        public void Test_Products() {
            var form = new Form1();
            // Установка данных для хот-догов
            form.HotDogPrice.Text = "129"; // цена за хот-дог
            form.HotDogCount.Text = "3"; // количество хот-догов
            form.HotDogCheckBox.Checked = true; // активация чекбокса
            // Установка данных для гамбургеров
            form.HamburgerPrice.Text = "117"; // цена за гамбургер
            form.HamburgerCount.Text = "2"; // количество гамбургеров
            form.HamburgerCheckBox.Checked = true; // активация чекбокса
            // Установка данных для картошки фри
            form.FrenchFriesPrice.Text = "130"; // цена за картошку фри
            form.FrenchFriesCount.Text = "4"; // количество картошки фри
            form.FrenchFriesCheckBox.Checked = true; // активация чекбокса
            // Установка данных для Coca-Cola
            form.CokoColaPrice.Text = "75"; // цена за Coca-Cola
            form.CokoColaCount.Text = "5"; // количество Coca-Cola
            form.CokoColaCheckBox.Checked = true; // активация чекбокса
            // Выполнение
            form.HotDogCount_TextChanged(form.HotDogCount, EventArgs.Empty);
            form.HamburgerCount_TextChanged(form.HamburgerCount, EventArgs.Empty);
            form.FrenchFriesCount_TextChanged(form.FrenchFriesCount, EventArgs.Empty);
            form.CokoColaCount_TextChanged(form.CokoColaCount, EventArgs.Empty);
            // Результат
            Assert.AreEqual(1516, form.PayCafe, "Сумма расчёта за продукты некорректна.");
        }
    }
}