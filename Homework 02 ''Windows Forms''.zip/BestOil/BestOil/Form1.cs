﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BestOil {
    public partial class Form1 : Form {
        double PayGasStation { get; set; } = 0; // сумма покупки топлива
        public double PayCafe { get; set; } = 0; // сумма покупки в кафе
        double PayTotal { get; set; } = 0; // общая сумма
        double cHot, cHam, cCol, cFri = 0; // переменные для хранения количества товаров кафе
        double[] oil = { 48.06, 52.23, 66.16, 66.42, 24.51 }; // цена топлива
        int tempTimer = 0; // итератор таймера
        public Form1() {
            InitializeComponent();
            this.Load += FormLoad;
        }
        public void FormLoad(object sender, EventArgs e) {
            comboBoxFuel.SelectedIndex = 0; // выбор определенного вида горючего
            textBoxFuelPrice.Text = $"{oil[0]}"; // цена на данный вид продукта
            //переключение кнопок RadioButton
            radioButtonCount.CheckedChanged += RadioButtonCheckedChanged;
            radioButtonSum.CheckedChanged += RadioButtonCheckedChanged;
            //выбор топлива
            comboBoxFuel.SelectedValueChanged += ComboBoxFuel_SelectedValueChanged;
            //вход на текстовое поле и выход из него
            textBoxRadioCount.Enter += TextBox_Enter;
            textBoxRadioCount.Leave += TextBox_Leave;
            textBoxRadioSum.Enter += TextBox_Enter;
            textBoxRadioSum.Leave += TextBox_Leave;
            HotDogCount.Enter += TextBox_Enter;
            HotDogCount.Leave += TextBox_Leave;
            FrenchFriesCount.Enter += TextBox_Enter;
            FrenchFriesCount.Leave += TextBox_Leave;
            CokoColaCount.Enter += TextBox_Enter;
            CokoColaCount.Leave += TextBox_Leave;
            HamburgerCount.Enter += TextBox_Enter;
            HamburgerCount.Leave += TextBox_Leave;
            //изменение значений в полях покупки топлива и подсчет суммы
            textBoxRadioCount.TextChanged += Radio_TextChanged;
            textBoxRadioSum.TextChanged += Radio_TextChanged;
            //CheckBox и изменение значений полей ReadOnly
            HotDogCheckBox.CheckedChanged += HotDogCheckBox_CheckedChanged;
            CokoColaCheckBox.CheckedChanged += CokoColaCheckBox_CheckedChanged;
            FrenchFriesCheckBox.CheckedChanged += FrenchFriesCheckBox_CheckedChanged;
            HamburgerCheckBox.CheckedChanged += HamburgerCheckBox_CheckedChanged;
            //изменение значений в полях покупки товаров в кафе и подсчет суммы
            HamburgerCount.TextChanged += HamburgerCount_TextChanged;
            HotDogCount.TextChanged += HotDogCount_TextChanged;
            CokoColaCount.TextChanged += CokoColaCount_TextChanged;
            FrenchFriesCount.TextChanged += FrenchFriesCount_TextChanged;
            //проверка на изменения значения вывода основной суммы
            toPayCafe.TextChanged += ToPayCafe_TextChanged;
            //нажатие кнопки рассчитать
            toCount.Click += ToCount_Click;
            //начало работы таймера
            timer.Tick += Timer_Tick;
            this.FormClosing += Form1_FormClosing;
        }

        public void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            if (PayTotal == 0)
                MessageBox.Show($"Продаж нет!", "Завершение программы", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show($"Общие продажи за {DateTime.Now.ToShortDateString()} = {Math.Round(PayTotal, 2)} руб.", "Завершение программы", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        public void Timer_Tick(object sender, EventArgs e) {
            Timer s = sender as Timer;
            tempTimer++;
            if (tempTimer == 10) {
                DialogResult result = MessageBox.Show("Завершить работу с этим клиентом?", "Очистить форму?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes) {
                    PayTotal += PayGasStation + PayCafe;
                    timer.Stop();
                    Text = $"BestOil Общие продажи за {DateTime.Now.ToShortDateString()} = {Math.Round(PayTotal, 2)} руб.";
                    CokoColaCheckBox.Checked = false;
                    HamburgerCheckBox.Checked = false;
                    HotDogCheckBox.Checked = false;
                    FrenchFriesCheckBox.Checked = false;
                    comboBoxFuel.SelectedIndex = 0;
                    radioButtonCount.Checked = true;
                    textBoxRadioCount.Text = "0,00";
                    tempTimer = 0;
                    toPayTotal.Text = "0,00";
                }
                else
                    tempTimer = 0;
            }
        }
        public void ToPayCafe_TextChanged(object sender, EventArgs e) {
            if (toPayCafe.Text == "0")
                toPayCafe.Text = "0,00";
        }
        public void HamburgerCheckBox_CheckedChanged(object sender, EventArgs e) {
            if (HamburgerCheckBox.Checked) {
                HamburgerCount.ReadOnly = false;
                HamburgerCount.Focus();
            }
            else {
                PayCafe -= (double.Parse(HamburgerPrice.Text) * cHam);
                cHam = 0;
                HamburgerCount.ReadOnly = true;
                HamburgerCount.Text = "0,00";
                toPayCafe.Text = Math.Round(PayCafe, 2).ToString();
            }
        }
        public void FrenchFriesCheckBox_CheckedChanged(object sender, EventArgs e) {
            if (FrenchFriesCheckBox.Checked) {
                FrenchFriesCount.ReadOnly = false;
                FrenchFriesCount.Focus();
            }
            else {
                PayCafe -= (double.Parse(FrenchFriesPrice.Text) * cFri);
                cFri = 0;
                FrenchFriesCount.ReadOnly = true;
                FrenchFriesCount.Text = "0,00";
                toPayCafe.Text = Math.Round(PayCafe, 2).ToString();
            }
        }
        public void CokoColaCheckBox_CheckedChanged(object sender, EventArgs e) {
            if (CokoColaCheckBox.Checked) {
                CokoColaCount.ReadOnly = false;
                CokoColaCount.Focus();
            }
            else {
                PayCafe -= (double.Parse(CokoColaPrice.Text) * cCol);
                cCol = 0;
                CokoColaCount.ReadOnly = true;
                CokoColaCount.Text = "0,00";
                toPayCafe.Text = Math.Round(PayCafe, 2).ToString();
            }
        }
        public void HotDogCheckBox_CheckedChanged(object sender, EventArgs e) {
            if (HotDogCheckBox.Checked) {
                HotDogCount.ReadOnly = false;
                HotDogCount.Focus();
            }
            else {
                PayCafe -= (double.Parse(HotDogPrice.Text) * cHot);
                cHot = 0;
                HotDogCount.ReadOnly = true;
                HotDogCount.Text = "0,00";
                toPayCafe.Text = Math.Round(PayCafe, 2).ToString();
            }
        }
        public void FrenchFriesCount_TextChanged(object sender, EventArgs e) {
            TextBox text = sender as TextBox;
            try {
                if (text.Text != "") {
                    if (double.Parse(text.Text) != cFri) {
                        PayCafe -= (double.Parse(FrenchFriesPrice.Text) * cFri);
                        cFri = double.Parse(text.Text);
                        PayCafe += (double.Parse(FrenchFriesPrice.Text) * cFri);
                        toPayCafe.Text = Math.Round(PayCafe, 2).ToString();
                    }
                }
            }
            catch (Exception) {
                text.Text = "0,00";
                MessageBox.Show("Некорректный ввод данных!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void CokoColaCount_TextChanged(object sender, EventArgs e) {
            TextBox text = sender as TextBox;
            try {
                if (text.Text != "") {
                    if (double.Parse(text.Text) != cCol) {
                        PayCafe -= (double.Parse(CokoColaPrice.Text) * cCol);
                        cCol = double.Parse(text.Text);
                        PayCafe += (double.Parse(CokoColaPrice.Text) * cCol);
                        toPayCafe.Text = Math.Round(PayCafe, 2).ToString();
                    }
                }
            }
            catch (Exception) {
                text.Text = "0,00";
                MessageBox.Show("Некорректный ввод данных!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void HotDogCount_TextChanged(object sender, EventArgs e) {
            TextBox text = sender as TextBox;
            try {
                if (text.Text != "") {
                    if (double.Parse(text.Text) != cHot) {
                        PayCafe -= (double.Parse(HotDogPrice.Text) * cHot);
                        cHot = double.Parse(text.Text);
                        PayCafe += (double.Parse(HotDogPrice.Text) * cHot);
                        toPayCafe.Text = Math.Round(PayCafe, 2).ToString();
                    }
                }
            }
            catch (Exception) {
                text.Text = "0,00";
                MessageBox.Show("Некорректный ввод данных!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void HamburgerCount_TextChanged(object sender, EventArgs e) {
            TextBox text = sender as TextBox;
            try {
                if (text.Text != "") {
                    if (double.Parse(text.Text) != cHam) {
                        PayCafe -= (double.Parse(HamburgerPrice.Text) * cHam);
                        cHam = double.Parse(text.Text);
                        PayCafe += (double.Parse(HamburgerPrice.Text) * cHam);
                        toPayCafe.Text = Math.Round(PayCafe, 2).ToString();
                    }
                }
            }
            catch (Exception) {
                text.Text = "0,00";
                MessageBox.Show("Некорректный ввод данных!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void ToCount_Click(object sender, EventArgs e) {
            if (PayGasStation + PayCafe != 0) {
                toPayTotal.Text = (Math.Round((PayGasStation + PayCafe), 2)).ToString();
                timer.Start();
            }
            else
                MessageBox.Show("Вы не совершили ни каких операций", "Внимание!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        public void Radio_TextChanged(object sender, EventArgs e) {
            TextBox text = sender as TextBox;
            try {
                if (radioButtonCount.Checked) {
                    PayGasStation = 0;
                    if (text.Text == "")
                        toPayGasStation.Text = "0,00";
                    else {
                        PayGasStation = double.Parse(textBoxFuelPrice.Text) * double.Parse(text.Text);
                        toPayGasStation.Text = Math.Round(PayGasStation, 2).ToString();
                    }
                }
                if (radioButtonSum.Checked) {
                    PayGasStation = 0;
                    if (text.Text == "")
                        toPayGasStation.Text = "0,00";
                    else {
                        PayGasStation = double.Parse(text.Text);
                        toPayGasStation.Text = Math.Round((double.Parse(text.Text) / double.Parse(textBoxFuelPrice.Text)), 2).ToString();
                    }
                }
            }
            catch (Exception) {
                text.Text = "0,00";
                MessageBox.Show("Некорректный ввод данных!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void TextBox_Leave(object sender, EventArgs e) {
            TextBox text = sender as TextBox;
            if (text.Text == "")
                text.Text = "0,00";
        }
        public void TextBox_Enter(object sender, EventArgs e) {
            TextBox text = sender as TextBox;
            if (text.Text == "0,00")
                text.Text = "";
        }
        public void ComboBoxFuel_SelectedValueChanged(object sender, EventArgs e) {
            ComboBox radio = sender as ComboBox;
            if (radio.SelectedIndex == 0)
                textBoxFuelPrice.Text = $"{oil[0]}";
            if (radio.SelectedIndex == 1)
                textBoxFuelPrice.Text = $"{oil[1]}";
            if (radio.SelectedIndex == 2)
                textBoxFuelPrice.Text = $"{oil[2]}";
            if (radio.SelectedIndex == 3)
                textBoxFuelPrice.Text = $"{oil[4]}";
            if (radio.SelectedIndex == 4)
                textBoxFuelPrice.Text = $"{oil[3]}";
            textBoxRadioCount.Text = "0,00";
            textBoxRadioSum.Text = "0,00";
            toPayGasStation.Text = "0,00";
        }
        public void RadioButtonCheckedChanged(object sender, EventArgs e) {
            if (radioButtonCount.Checked) {
                textBoxRadioCount.ReadOnly = false;
                textBoxRadioSum.ReadOnly = true;
                textBoxRadioSum.Text = "0,00";
                toPayGasStation.Text = "0,00";
                groupBoxFuel.Text = "К оплате";
                label5.Text = "руб.";
                textBoxRadioCount.Focus();
            }
            if (radioButtonSum.Checked) {
                textBoxRadioCount.ReadOnly = true;
                textBoxRadioSum.ReadOnly = false;
                textBoxRadioCount.Text = "0,00";
                toPayGasStation.Text = "0,00";
                groupBoxFuel.Text = "К выдаче";
                label5.Text = "л.";
                textBoxRadioSum.Focus();
            }
        }
    }
}

/*Порядок действий:
1.  Запустить Visual Studio Installer окно «Установленные продукты» -> кнопка «Изменить» -> установить флажок 
    «Разработка классических приложений .NET».
2.  Щелчок правой кнопкой по Решение «BestOil» -> пункт меню «Добавить» -> пункт подменю «Создать проект…» -> 
    выбрать: 1-ое поле – «C#»; 2-ое – «Все платформы»; 3-ье – «Тестирование» -> выбрать в списке «Проект модульного 
    теста (.NET Framework)» -> кнопка «Далее» -> имя проекта «BestOil.Tests» -> кнопка «Создать» -> в обозревателе 
    решений переименовать файл тестового проекта «UnitTest1.cs» в «Form1Tests.cs» -> написать код.
3.  В обозревателе решений щелчок правой кнопкой по проекту «BestOil.Tests» -> пункт меню «Добавить» -> пункт 
    подменю «Ссылка…» -> в разделе «Сборки» установить флажок рядом с «System.Windows.Forms»-> кнопка «OK».
4.  В обозревателе решений щелчок правой кнопкой по проекту «BestOil.Tests» -> пункт меню «Добавить» -> пункт 
    подменю «Ссылка…» -> в разделе «Проекты» установить флажок рядом с «BestOil» -> кнопка «OK».
5.  В обозревателе решений раскрыть проект «BestOil» -> в самом проекте – «Form1.cs» -> двойной щелчок по файлу 
    «Form1Designer.cs». В меню Visual Studio пункт «Правка» -> подпункт «Найти и заменить» -> подпункт «Быстрая замена» 
    -> в верхнее поле внести: private; в нижнее: public -> кнопка «Заменить все». Аналогичным образом (двойной щелчок 
    + [F7]) произвести замену в коде файла «Form1.cs», дополнительно заменив double PayCafe на public double PayCafe.
6.  В меню Visual Studio выбрать пункт «Тест» -> подпункт «Обозреватель тестов» -> откроется окно, содержащее все 
    тесты проекта -> кнопка «Выполнить все тесты в представлении» [рисунок на кнопке  –  два треугольника белый 
    и зелёный].
7.  Если какой-либо тест не проходит, появится сообщение об ошибке, объясняющее, что пошло не так (например, 
    возвращённое значение не совпадает с ожидаемым).*/

/*ВНИМАНИЕ!
I. Основной проект (BestOil) и тестовый проект (BestOil.Tests) ДОЛЖНЫ БЫТЬ НАСТРОЕНЫ ДЛЯ ОДНОЙ ВЕРСИИ .NET Framework 
    или .NET. Если, например, BestOil создан на .NET Framework 4.7.2, а BestOil.Tests – .NET 8.0, программа запустится, 
    но все тесты покажут ошибку!
    УЗНАТЬ ВЕРСИЮ ПЛАТФОРМЫ: щелчок правой кнопкой по проекту «BestOil» -> пункт меню «Свойства» -> в открывшемся окне 
    вкладка «Приложение» -> в поле «Целевая рабочая среда» отображается версия платформы. Порядок действий для 
    BestOil.Tests – аналогичен.
II. Варианты повторного запуска тестов (ЕСЛИ ОНИ УЖЕ БЫЛИ ПРОЙДЕНЫ, ТЕСТЫ НЕ ПОЛУЧИТЬСЯ ЗАПУСТИТЬ ПОВТОРНО, КАК УКАЗАНО 
    В ПУНКТЕ 6 – НЕОБХОДИМО СБРОСИТЬ РЕЗУЛЬТАТЫ!):
    а) в меню Visual Studio выбрать пункт «Сборка» -> подпункт «Пересобрать решение» (или пункт «Сборка» -> подпункт 
        «Очистить решение», затем опять пункт «Сборка» -> подпункт «Собрать решение»), далее – в соответствии с пунктом 6;
    б) в меню Visual Studio выбрать пункт «Тест» -> подпункт «Обозреватель тестов» -> откроется окно, содержащее все 
        тесты проекта -> стрелка вниз кнопки «Запустить» [рисунок на кнопке – зелёный треугольник] -> пункт «Повторить 
        последний запуск».*/

/*Задание: Возьмите Ваше приложение выполненное в рамках курсовой по c# и покройте его юнит-тестами.*/