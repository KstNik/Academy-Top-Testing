﻿using ArraySumApp;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ArraySumAppTests {
    [TestClass]
    public class ArraySumTests {
        [TestMethod]
        public void CalculateArraySum_EmptyArray_ReturnsZero() {
            int[] array = { };
            int expected = 0;
            int result = Program.CalculateArraySum(array);
            Assert.AreEqual(expected, result, "Сумма пустого массива равна 0");
        }
        [TestMethod]
        public void CalculateArraySum_SingleElementArray_ReturnsElement() {
            int[] array = { 5 };
            int expected = 5;
            int result = Program.CalculateArraySum(array);
            Assert.AreEqual(expected, result, "Сумма массива из одного элемента равна этому элементу");
        }
        [TestMethod]
        public void CalculateArraySum_MixedNumbers_ReturnsCorrectSum() {
            int[] array = { 1, -2, 3, 4 };
            int expected = 6;
            int result = Program.CalculateArraySum(array);
            Assert.AreEqual(expected, result);
        }
        [TestMethod]
        public void CalculateArraySum_AllZeros_ReturnsZero() {
            int[] array = { 0, 0, 0 };
            int expected = 0;
            int result = Program.CalculateArraySum(array);
            Assert.AreEqual(expected, result, "Сумма массива, все элементы которого 0, равна 0");
        }
        [TestMethod]
        public void CalculateArraySum_AllPositiveNumbers_ReturnsCorrectSum() {
            int[] array = { 1, 2, 3, 4, 5 };
            int expected = 15;
            int result = Program.CalculateArraySum(array);
            Assert.AreEqual(expected, result);
        }
    }
}